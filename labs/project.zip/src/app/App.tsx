import { StudyHeader } from "./components/study-header";
import { KPICards } from "./components/kpi-cards";
import { StudyTimeline } from "./components/study-timeline";
import { PatientsAttention } from "./components/patients-attention";

// Mock data for the clinical study dashboard
const studyData = {
  studyName: "Chronic Pain Management Study - Phase II",
  studyId: "CPM-2024-037",
  status: "active" as const,
  startDate: "Sep 15, 2025",
  endDate: "Mar 15, 2026",
  currentWeek: 18,
  totalWeeks: 26,
};

const kpiData = {
  totalParticipants: 124,
  activeParticipants: 118,
  dataCompleteness: 87,
  activeAlerts: 7,
};

const timelineData = [
  { week: "Week 11", questionnaires: 112, sensorData: 845, gaps: 12 },
  { week: "Week 12", questionnaires: 118, sensorData: 892, gaps: 6 },
  { week: "Week 13", questionnaires: 115, sensorData: 876, gaps: 9 },
  { week: "Week 14", questionnaires: 110, sensorData: 821, gaps: 14 },
  { week: "Week 15", questionnaires: 119, sensorData: 901, gaps: 5 },
  { week: "Week 16", questionnaires: 116, sensorData: 884, gaps: 8 },
  { week: "Week 17", questionnaires: 121, sensorData: 915, gaps: 3 },
  { week: "Week 18", questionnaires: 108, sensorData: 798, gaps: 16 },
];

const patientsData = [
  {
    id: "PT-0847",
    name: "Patient 0847",
    reason: "Missing sensor data for 4 consecutive days",
    severity: "high" as const,
    lastActive: "5 days ago",
    details: "Last wearable sync: Jan 28, 2026. Device may be offline or discharged.",
  },
  {
    id: "PT-0923",
    name: "Patient 0923",
    reason: "Pain score anomaly detected",
    severity: "high" as const,
    lastActive: "2 hours ago",
    details: "Reported pain level 9/10, significantly above baseline. Protocol recommends clinical review.",
  },
  {
    id: "PT-0756",
    name: "Patient 0756",
    reason: "Questionnaire overdue by 3 days",
    severity: "medium" as const,
    lastActive: "3 days ago",
    details: "Weekly pain assessment not completed. Last submission: Jan 29, 2026.",
  },
  {
    id: "PT-1092",
    name: "Patient 1092",
    reason: "Irregular sensor pattern",
    severity: "medium" as const,
    lastActive: "1 day ago",
    details: "Activity data shows unusual patterns. May indicate device positioning issue.",
  },
  {
    id: "PT-0634",
    name: "Patient 0634",
    reason: "Approaching protocol milestone",
    severity: "low" as const,
    lastActive: "4 hours ago",
    details: "Day 90 follow-up scheduled for Jan 5, 2026. All data current.",
  },
  {
    id: "PT-0812",
    name: "Patient 0812",
    reason: "Low engagement score this week",
    severity: "medium" as const,
    lastActive: "6 hours ago",
    details: "Completed only 2 of 5 daily check-ins. Engagement trending downward.",
  },
  {
    id: "PT-0971",
    name: "Patient 0971",
    reason: "Wearable battery low alert",
    severity: "medium" as const,
    lastActive: "8 hours ago",
    details: "Device battery at 12%. Patient notified to charge device.",
  },
];

export default function App() {
  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-7xl mx-auto p-6 space-y-6">
        {/* Study Header */}
        <StudyHeader {...studyData} />

        {/* KPI Cards */}
        <KPICards {...kpiData} />

        {/* Timeline and Patients Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          {/* Timeline - Takes 3 columns on large screens */}
          <div className="lg:col-span-3">
            <StudyTimeline data={timelineData} />
          </div>

          {/* Patients Needing Attention - Takes 2 columns on large screens */}
          <div className="lg:col-span-2">
            <PatientsAttention patients={patientsData} />
          </div>
        </div>
      </div>
    </div>
  );
}
