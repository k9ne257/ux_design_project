import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

interface TimelineData {
  week: string;
  questionnaires: number;
  sensorData: number;
  gaps: number;
}

interface StudyTimelineProps {
  data: TimelineData[];
}

export function StudyTimeline({ data }: StudyTimelineProps) {
  return (
    <div className="bg-white border border-slate-200 rounded-lg p-6">
      <div className="mb-6">
        <h3 className="text-slate-900 mb-1">Study Activity Timeline</h3>
        <p className="text-slate-500 text-sm">
          Weekly data collection overview for the past 8 weeks
        </p>
      </div>

      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={data} barGap={4}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
          <XAxis
            dataKey="week"
            tick={{ fill: "#64748b", fontSize: 13 }}
            axisLine={{ stroke: "#e2e8f0" }}
            tickLine={false}
          />
          <YAxis
            tick={{ fill: "#64748b", fontSize: 13 }}
            axisLine={{ stroke: "#e2e8f0" }}
            tickLine={false}
            label={{ value: "Data Points", angle: -90, position: "insideLeft", fill: "#64748b", fontSize: 13 }}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: "#ffffff",
              border: "1px solid #e2e8f0",
              borderRadius: "8px",
              fontSize: "13px",
            }}
            cursor={{ fill: "#f8fafc" }}
          />
          <Legend
            wrapperStyle={{ fontSize: "13px", paddingTop: "20px" }}
            iconType="circle"
          />
          <Bar
            dataKey="questionnaires"
            fill="#10b981"
            radius={[4, 4, 0, 0]}
            name="Questionnaires Completed"
          />
          <Bar
            dataKey="sensorData"
            fill="#3b82f6"
            radius={[4, 4, 0, 0]}
            name="Sensor Data Points"
          />
          <Bar
            dataKey="gaps"
            fill="#f59e0b"
            radius={[4, 4, 0, 0]}
            name="Missing Data"
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
