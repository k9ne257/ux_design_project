import { Users, Activity, Bell } from "lucide-react";

interface KPICardsProps {
  totalParticipants: number;
  activeParticipants: number;
  dataCompleteness: number;
  activeAlerts: number;
}

export function KPICards({
  totalParticipants,
  activeParticipants,
  dataCompleteness,
  activeAlerts,
}: KPICardsProps) {
  const completenessColor =
    dataCompleteness >= 90
      ? "text-emerald-600"
      : dataCompleteness >= 70
      ? "text-amber-600"
      : "text-red-600";

  const alertColor = activeAlerts > 5 ? "text-red-600" : "text-slate-600";

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
      {/* Total Participants */}
      <div className="bg-white border border-slate-200 rounded-lg p-5">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 bg-slate-50 rounded-lg flex items-center justify-center">
            <Users className="w-5 h-5 text-slate-600" />
          </div>
          <p className="text-slate-500 text-sm">Participants</p>
        </div>
        <div className="space-y-1">
          <p className="text-slate-900 text-3xl">{totalParticipants}</p>
          <p className="text-slate-500 text-xs">
            {activeParticipants} active this week
          </p>
        </div>
      </div>

      {/* Data Completeness */}
      <div className="bg-white border border-slate-200 rounded-lg p-5">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 bg-slate-50 rounded-lg flex items-center justify-center">
            <Activity className="w-5 h-5 text-slate-600" />
          </div>
          <p className="text-slate-500 text-sm">Data Completeness</p>
        </div>
        <div className="space-y-1">
          <p className={`text-3xl ${completenessColor}`}>
            {dataCompleteness}%
          </p>
          <p className="text-slate-500 text-xs">Last 7 days</p>
        </div>
      </div>

      {/* Active Alerts */}
      <div className="bg-white border border-slate-200 rounded-lg p-5">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 bg-slate-50 rounded-lg flex items-center justify-center">
            <Bell className="w-5 h-5 text-slate-600" />
          </div>
          <p className="text-slate-500 text-sm">Active Alerts</p>
        </div>
        <div className="space-y-1">
          <p className={`text-3xl ${alertColor}`}>{activeAlerts}</p>
          <p className="text-slate-500 text-xs">Require attention</p>
        </div>
      </div>

      {/* Compliance Rate */}
      <div className="bg-white border border-slate-200 rounded-lg p-5">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 bg-slate-50 rounded-lg flex items-center justify-center">
            <Activity className="w-5 h-5 text-slate-600" />
          </div>
          <p className="text-slate-500 text-sm">Compliance Rate</p>
        </div>
        <div className="space-y-1">
          <p className="text-slate-900 text-3xl">87%</p>
          <p className="text-slate-500 text-xs">Protocol adherence</p>
        </div>
      </div>
    </div>
  );
}
