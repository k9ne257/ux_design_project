import { CircleAlert, CircleCheck, CircleX, ChevronRight } from "lucide-react";

type Severity = "high" | "medium" | "low";

interface Patient {
  id: string;
  name: string;
  reason: string;
  severity: Severity;
  lastActive: string;
  details: string;
}

interface PatientsAttentionProps {
  patients: Patient[];
}

export function PatientsAttention({ patients }: PatientsAttentionProps) {
  const getSeverityIcon = (severity: Severity) => {
    switch (severity) {
      case "high":
        return <CircleX className="w-5 h-5 text-red-600" />;
      case "medium":
        return <CircleAlert className="w-5 h-5 text-amber-600" />;
      case "low":
        return <CircleCheck className="w-5 h-5 text-slate-400" />;
    }
  };

  const getSeverityBg = (severity: Severity) => {
    switch (severity) {
      case "high":
        return "bg-red-50";
      case "medium":
        return "bg-amber-50";
      case "low":
        return "bg-slate-50";
    }
  };

  // Sort patients by severity
  const sortedPatients = [...patients].sort((a, b) => {
    const severityOrder = { high: 0, medium: 1, low: 2 };
    return severityOrder[a.severity] - severityOrder[b.severity];
  });

  return (
    <div className="bg-white border border-slate-200 rounded-lg">
      <div className="p-6 border-b border-slate-200">
        <h3 className="text-slate-900 mb-1">Patients Requiring Attention</h3>
        <p className="text-slate-500 text-sm">
          {patients.filter((p) => p.severity === "high").length} high priority ·{" "}
          {patients.filter((p) => p.severity === "medium").length} medium priority
        </p>
      </div>

      <div className="divide-y divide-slate-100">
        {sortedPatients.map((patient) => (
          <div
            key={patient.id}
            className={`p-5 hover:bg-slate-50 transition-colors cursor-pointer ${getSeverityBg(
              patient.severity
            )} border-l-4 ${
              patient.severity === "high"
                ? "border-l-red-600"
                : patient.severity === "medium"
                ? "border-l-amber-600"
                : "border-l-slate-300"
            }`}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-4 flex-1">
                <div className="mt-0.5">{getSeverityIcon(patient.severity)}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-3 mb-1">
                    <p className="text-slate-900">{patient.name}</p>
                    <span className="text-slate-400 text-xs">ID: {patient.id}</span>
                  </div>
                  <p className="text-slate-600 text-sm mb-2">{patient.reason}</p>
                  <p className="text-slate-500 text-xs">{patient.details}</p>
                  <p className="text-slate-400 text-xs mt-2">
                    Last active: {patient.lastActive}
                  </p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-slate-400 flex-shrink-0 mt-1" />
            </div>
          </div>
        ))}
      </div>

      {sortedPatients.length === 0 && (
        <div className="p-12 text-center">
          <CircleCheck className="w-12 h-12 text-emerald-600 mx-auto mb-3" />
          <p className="text-slate-600">All patients are on track</p>
          <p className="text-slate-400 text-sm mt-1">No immediate attention required</p>
        </div>
      )}
    </div>
  );
}
