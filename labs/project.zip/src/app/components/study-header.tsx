import { Calendar, Clock } from "lucide-react";

interface StudyHeaderProps {
  studyName: string;
  studyId: string;
  status: "active" | "paused" | "completed";
  startDate: string;
  endDate: string;
  currentWeek: number;
  totalWeeks: number;
}

export function StudyHeader({
  studyName,
  studyId,
  status,
  startDate,
  endDate,
  currentWeek,
  totalWeeks,
}: StudyHeaderProps) {
  const statusColors = {
    active: "bg-emerald-50 text-emerald-700 border-emerald-200",
    paused: "bg-amber-50 text-amber-700 border-amber-200",
    completed: "bg-slate-100 text-slate-700 border-slate-200",
  };

  return (
    <div className="bg-white border border-slate-200 rounded-lg p-6">
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <h1 className="text-slate-900">{studyName}</h1>
            <span
              className={`px-3 py-1 rounded-full border text-sm ${statusColors[status]}`}
            >
              {status.charAt(0).toUpperCase() + status.slice(1)}
            </span>
          </div>
          <p className="text-slate-500 text-sm">Study ID: {studyId}</p>
        </div>
      </div>

      <div className="flex items-center gap-8 mt-6 pt-6 border-t border-slate-100">
        <div className="flex items-center gap-2 text-slate-600">
          <Calendar className="w-4 h-4" />
          <span className="text-sm">
            {startDate} — {endDate}
          </span>
        </div>
        <div className="flex items-center gap-2 text-slate-600">
          <Clock className="w-4 h-4" />
          <span className="text-sm">
            Week {currentWeek} of {totalWeeks}
          </span>
        </div>
      </div>
    </div>
  );
}
